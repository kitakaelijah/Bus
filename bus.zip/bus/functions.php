<?php
 
	// Check If form submitted, insert form data into trip table.
	if(isset($_POST['Submit'])) {
        $field3 = $_POST['origin'];
        $field4 = $_POST['destination'];
        if( $field3 != $field4){ 
		
            
        $field1 = $_POST['username'];
        $field2 = $_POST['phone'];
        $field3 = $_POST['origin'];
        $field4 = $_POST['destination'];
        $field5 = $_POST['PickupDate'];
        $field6 = $_POST['PickupTime'];
        $field7 = $_POST['ReturnDate'];
        $field8 = $_POST['ReturnTime'];
        $field9 = $_POST['adults'];
        $field10 = $_POST['children'];
        $field11 = $field3.rand (10,100);
        $field12=$field3.rand(1,60);
        $field13 = $field9 + $field10;
        

	
       
        

       
		// include database connection file
		include_once("config.php");
				
		// Insert user data into table
		$result1 = mysqli_query($mysqli, "INSERT INTO `trip`(`name`, `phone`, `origin`, `destination`, `pickupdate`, `pickuptime`, `returndate`, `returntime`, `adults`, `children`)VALUES('$field1','$field2','$field3','$field4','$field5','$field6','$field7','$field8','$field9','$field10')");
	

      if($field3 == 'kampala' and $field4  == 'jinja' )
      {

                $cost = 30000;
      }else if ($field4 == 'kampala' and $field3  == 'jinja'){
        $cost = 30000;
      
      
      
      
    }else if($field3 == 'wakiso' and $field4  == 'jinja'   )
      {

                    $cost = 40000;
        }else if ( $field4 == 'wakiso' and $field3  == 'jinja'){


            $cost = 40000;


        } 
        
        
        
        
        
        
        else {

                 $cost = 50000;
        }
        $totalcost = $cost* $field13;
                echo'
                
                
                
                
                
                
                
                
                
                
                

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Bus Booking</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style2.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesnt work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
<style>body{
  background-image: url("bus.jpg");
}</style>
</head>

<body>
	<div id="booking" class="section">
		<div class="section-center">
			<div class="container">
				<div class="row">
					
					<div class="col-md-12 col-md-offset-1">
						<div class="booking-form">
						
							<h3>Book a Bus with Kinyera Charles Online Bus Booking System</h3>	
                            <?php include("functions.php");
                            
							<p>Yor trip from  ' .$field3.'  to  '.$field4. '</p>
                            <p> is scheduled on '.$field5.' </p>
                            <p> at '.$field6.'
                            <p> and return is on '.$field7.' at '.$field8.'</p>
                            <p> Number of Sits booked:- '.$field13.'</p>
                            <p>Will cost you:- UGX' .   $totalcost. '</p>
                            <p> Ticket Number:- '.$field3.rand (10,100).'</p>
                           

                            

							<div class="row">
                                <div class="col-md-6">
								<div class="form-btn">
									<a><button class="submit-btn">Successfully Booked Trip</button></a>
								</div>
                                </div>
                               <!-- <div class="col-md-6">
                                <div class="form-btn">
									<a href="index2.html"><button class="submit-btn">Print</button></a>
								</div>
                                </div>
                                    -->                     
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>

</html>
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                ';


                $result = mysqli_query($mysqli, "INSERT INTO `trip_ticket`(`username`,`phone`,`ticket_number`, `sit_number`, `pickupdate`, `pickuptime`,`returndate`,`returntime`, `origin`, `destination`, `numberofsits`, `costs`) VALUES('$field1','$field2','$field11','$field12','$field5', '$field6','$field7','$field8','$field3','$field4','$field13',$totalcost)");
               if(mysqli_query($mysqli, $result)){
                  echo "Records inserted successfully.";
              } else{
                  echo "ERROR: Could not able to execute $result. " . mysqli_error($mysqli);
              }
                                                                                                                                                                          

    

     	
	
	/*	echo "<script>
        window.location.href = 'cost.php';
      </script>;";
      */
      









        }else{
        
        echo"<script>alert('Pickup and Destination cant be the same');</script>";
        echo "<script>
        window.location.href = 'index2.html';
      </script>;";
        }
    }
    





    ///single trip

    // Check If form submitted, insert form data into trip table.
	if(isset($_POST['Submit1'])) {
    $field3 = $_POST['origin'];
    $field4 = $_POST['destination'];
    if( $field3 != $field4){ 

        
    $field1 = $_POST['username'];
    $field2 = $_POST['phone'];
    $field3 = $_POST['origin'];
    $field4 = $_POST['destination'];
    $field5 = $_POST['PickupDate'];
    $field6 = $_POST['PickupTime'];
    $field7 = "N/A";
    $field8 = "N/A";
    $field9 = $_POST['adults'];
    $field10 = $_POST['children'];
    $field11 = $field3.rand (10,100);
    $field12=$field3.rand(1,60);
    $field13 = $field9 + $field10;
    


   
    

   
// include database connection file
include_once("config.php");
    
// Insert user data into table
$result1 = mysqli_query($mysqli, "INSERT INTO `trip`(`name`, `phone`, `origin`, `destination`, `pickupdate`, `pickuptime`, `returndate`, `returntime`, `adults`, `children`)VALUES('$field1','$field2','$field3','$field4','$field5','$field6','$field7','$field8','$field9','$field10')");


  if($field3 == 'kampala' and $field4  == 'jinja' )
  {

            $cost = 30000;
  }else if ($field4 == 'kampala' and $field3  == 'jinja'){
    $cost = 30000;
  
  
  
  
}else if($field3 == 'wakiso' and $field4  == 'jinja'   )
  {

                $cost = 40000;
    }else if ( $field4 == 'wakiso' and $field3  == 'jinja'){


        $cost = 40000;


    } 
    
    
    
    
    
    
    else {

             $cost = 50000;
    }
    $totalcost = $cost* $field13;
            echo'
            
            
            
            
            
            
            
            
            
            
            

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

<title>Bus Booking</title>

<!-- Google font -->
<link href="https://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet">

<!-- Bootstrap -->
<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

<!-- Custom stlylesheet -->
<link type="text/css" rel="stylesheet" href="css/style2.css" />

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesnt work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<style>body{
background-image: url("bus.jpg");
}</style>
</head>

<body>
<div id="booking" class="section">
<div class="section-center">
  <div class="container">
    <div class="row">
      
      <div class="col-md-12 col-md-offset-1">
        <div class="booking-form">
        
          <h3>Book a Bus with Kinyera Charles Online Bus Booking System</h3>	
                        <?php include("functions.php");
                        
          <p>Yor trip from  ' .$field3.'  to  '.$field4. '</p>
                        <p> is scheduled on '.$field5.' </p>
                        <p> at '.$field6.'
                        
                        <p> Number of Sits booked:- '.$field13.'</p>
                        <p>Will cost you:- UGX' .   $totalcost. '</p>
                        <p> Ticket Number:- '.$field3.rand (10,100).'</p>
                      

                        

          <div class="row">
                            <div class="col-md-6">
            <div class="form-btn">
              <a><button class="submit-btn">Successfully Booked Trip</button></a>
            </div>
                            </div>
                           <!-- <div class="col-md-6">
                            <div class="form-btn">
              <a href="index2.html"><button class="submit-btn">Print</button></a>
            </div>
                            </div>
                                -->                     
          
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</body>

</html>
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            ';


            $result = mysqli_query($mysqli, "INSERT INTO `trip_ticket`(`username`,`phone`,`ticket_number`, `sit_number`, `pickupdate`, `pickuptime`,`returndate`,`returntime`, `origin`, `destination`, `numberofsits`, `costs`) VALUES('$field1','$field2','$field11','$field12','$field5', '$field6','$field7','$field8','$field3','$field4','$field13',$totalcost)");
           if(mysqli_query($mysqli, $result)){
              echo "Records inserted successfully.";
          } else{
              echo "ERROR: Could not able to execute $result. " . mysqli_error($mysqli);
          }
                                                                                                                                                                      



   

/*	echo "<script>
    window.location.href = 'cost.php';
  </script>;";
  */
  









    }else{
    
    echo"<script>alert('Pickup and Destination cant be the same');</script>";
    echo "<script>
    window.location.href = 'index1.html';
  </script>;";
    }
}



	?>