<?php


include_once("../config.php");

$ticket_number = $_POST['ticket_number'];
$del = mysqli_query($mysqli, "DELETE FROM `trip_ticket` WHERE `trip_ticket`.`ticket_number` = '$ticket_number';
");
if(mysqli_query($mysqli, $del)){
   echo "Records Deleted successfully.";
   echo "<script>
   window.location.href = 'crud.php';
 </script>;";
} else{
   echo "<script>alert('Record Not found');</script>";
   echo "<script>
   window.location.href = 'crud.php';
 </script>;";
}



?>