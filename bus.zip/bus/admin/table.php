<?php
include"header.php";
?>


            <div class="col-lg-12 stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Adminstrator's Data View</h4>
                  <p class="card-description">
                    
                  </p>
                  <div class="table-responsive pt-3">
                    <table class="table table-bordered">
                      <thead>
                        <tr class="">
                          <th>
                            #
                          </th>
                          <th>
                            Name
                          </th>
                          <th>
                            Phone 
                          </th>
                          <th>
                            Ticket Number
                          </th>
                          <th>
                         Number of Sits
                          </th>
                          <th>
                          Pickup Date
                          </th>
                          <th>
                          Pickup Time
                          </th>
                          <th>
                          Return Date
                          </th>
                          <th>
                          Return Time
                          </th>
                          <th>
                          Origin
                          </th>
                          <th>
                          Destination
                          </th>
                          <th>
                          Costs
                          </th>
                          <th>
                         Timestamp
                          </th>
                        </tr>
                      </thead>
                      <tbody>
<?php

                      if(! $conn ) {
      die('Could not connect: ' . mysql_error());
   }
   
   $sql = 'SELECT `id`,`username`,  `phone`, `ticket_number`, `numberofsits`, `pickupdate`, `pickuptime`, `returndate`, `returntime`, `origin`, `destination`,  `costs`, `timestamp` FROM `trip_ticket`';
   mysqli_select_db($conn,'bus');
   $retval = mysqli_query(  $conn,$sql );
   
   if(! $retval ) {
      die('Could not get data: ' . mysqli_error());
   }
   
   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) {
     
      


                        $colors =array("table-primary","table-warning","table-danger","table-danger","table-success","table-primary");
                        $i= rand(0,5);
                       $randomColorselector = $colors[$i] ;

                         echo"<tr class=".$randomColorselector.">";

                          echo "<td> ".$row['id']."</td>";

                          echo "<td> ".$row['username']."</td>";

                          echo "<td>".$row['phone']."</td>";


                          echo "<td> ".$row['ticket_number']."</td>";

                          echo "<td> ".$row['numberofsits']."</td>";

                          echo "<td> ".$row['pickupdate']."</td>";

                          echo "<td> ".$row['pickuptime']."</td>";

                          echo "<td> ".$row['returndate']."</td>";

                          echo "<td> ".$row['returntime']."</td>";

                          echo "<td> ".$row['origin']."</td>";

                          echo "<td> ".$row['destination']."</td>";

                          echo "<td> ".$row['costs']."</td>";
                         
                          echo "<td> ".$row['timestamp']."</td>";
                        

                         
                    }
                    
                   // echo "Fetched data successfully\n";
                    
                    mysqlI_close($conn);
                          ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
 <!-- plugins:js -->
 <script src="vendors/js/vendor.bundle.base.js"></script>
 <!-- endinject -->
 <!-- Plugin js for this page -->
 <script src="vendors/chart.js/Chart.min.js"></script>
 <script src="vendors/datatables.net/jquery.dataTables.js"></script>
 <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
 <script src="js/dataTables.select.min.js"></script>

 <!-- End plugin js for this page -->
 <!-- inject:js -->
 <script src="js/off-canvas.js"></script>
 <script src="js/hoverable-collapse.js"></script>
 <script src="js/template.js"></script>
 <script src="js/settings.js"></script>
 <script src="js/todolist.js"></script>
 <!-- endinject -->
 <!-- Custom js for this page-->
 <script src="js/dashboard.js"></script>
 <script src="js/Chart.roundedBarCharts.js"></script>
 <!-- End custom js for this page-->
</body>

</html>

