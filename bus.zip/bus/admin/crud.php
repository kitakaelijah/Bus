<?php include"header.php";
?>
 <!-- partial -->

 <div class="main-panel">        
        <div class="content-wrapper">
          <div class="row">
            
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Add Trip</h4>
                  <p class="card-description">
                    Add Trip
                  </p>
                 
                   
                  

                  <form  class="forms-sample" action ="adminadd.php" method="POST">
								
                                <h3>Book a Bus with Kinyera Charles Online Bus Booking System</h3>	
                                
                                
                                <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <span class="form-label">Enter Your Name: </span>
                                                <input class="form-control" type="text" placeholder="First Name and Last Name" name ="username">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <span class="form-label">Enter Phone Number:</span>
                                                <input class="form-control" type="text" placeholder="Mobile Number" name ="phone">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <span class="form-label">Enter an Origin location (From):</span>
                                                <select class="form-control" name= "origin">
                                                    <option value ="Kampala">Kampala</option>
                                                    <option value="Wakiso">Wakiso</option>
                                                    <option value="jinja">jinja</option>
                                                </select>
                                                <span class="select-arrow"></span>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <span class="form-label">Enter A Destination location  (To):</span>
                                                <select class="form-control" name= "destination">
                                                    <option value ="Kampala">Kampala</option>
                                                    <option value="Wakiso">Wakiso</option>
                                                    <option value="jinja">jinja</option>
                                                </select>
                                                <span class="select-arrow"></span>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    
                                   
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <span class="form-label">Pickup Date</span>
                                                <input class="form-control" type="date" name = "PickupDate" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <span class="form-label">Pickup Time</span>
                                                <input class="form-control" type="time" name = "PickupTime" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <span class="form-label">Return Date</span>
                                                <input class="form-control" type="date" name ="ReturnDate" >
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <span class="form-label">Return Time</span>
                                                <input class="form-control" type="time" name="ReturnTime" >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <span class="form-label">Adults (18+)</span>
                                                <select class="form-control" name ="adults">
                                                    <option value = 1>1</option>
                                                    <option value = 2>2</option>
                                                    <option value = 3>3</option>
                                                    <option value = 4>4</option>
                                                    <option value = 5>5</option>
                                                    <option value = 6>6</option>
                                                    <option value = 7>7</option>
                                                    <option value = 8>8</option>
                                                    <option value = 9>9</option>
                                                    <option value = 10>10</option>
                                                    <option value = 11>11</option>
                                                    <option value = 12>12</option>
                                                    <option value = 13>13</option>
                                                    <option value = 14>14</option>
                                                    <option value = 15>15</option>
                                                    <option value = 16>16</option>
                                                    <option value = 17>17</option>
                                                    <option value = 18>18</option>
                                                    <option value = 19>19</option>
                                                    <option value = 20>20</option>
                                                    <option value = 21>21</option>
                                                    <option value = 22>22</option>
                                                    <option value = 23>23</option>
                                                    <option value = 24>24</option>
                                                    <option value = 25>25</option>
                                                    <option value = 26>26</option>
                                                    <option value = 27>27</option>
                                                    <option value = 28>28</option>
                                                    <option value = 29>29</option>
                                                    <option value = 30>30</option>
                                                </select>
                                                <span class="select-arrow"></span>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <span class="form-label">Children (0-17)</span>
                                                <select class="form-control" name ="children">
                                                    <option value = 0>0</option>
                                                    <option value = 1>1</option>
                                                    <option value = 2>2</option>
                                                    <option value = 3>3</option>
                                                    <option value = 4>4</option>
                                                    <option value = 5>5</option>
                                                    <option value = 6>6</option>
                                                    <option value = 7>7</option>
                                                    <option value = 8>8</option>
                                                    <option value = 9>9</option>
                                                    <option value = 10>10</option>
                                                    <option value = 11>11</option>
                                                    <option value = 12>12</option>
                                                    <option value = 13>13</option>
                                                    <option value = 14>14</option>
                                                    <option value = 15>15</option>
                                                    <option value = 16>16</option>
                                                    <option value = 17>17</option>
                                                    <option value = 18>18</option>
                                                    <option value = 19>19</option>
                                                    <option value = 20>20</option>
                                                    <option value = 21>21</option>
                                                    <option value = 22>22</option>
                                                    <option value = 23>23</option>
                                                    <option value = 24>24</option>
                                                    <option value = 25>25</option>
                                                    <option value = 26>26</option>
                                                    <option value = 27>27</option>
                                                    <option value = 28>28</option>
                                                    <option value = 29>29</option>
                                                    
                                                </select>
                                                <span class="select-arrow"></span>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="form-btn">
                                        <button  class="btn btn-primary mr-2" name="Submit">Add Booking</button>

                                    </div>



                    









                                </form>











                </div>
              </div>
            </div>
            <div class="col-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Delete Booking</h4>
                  <p class="card-description">
                  Enter ticket number to be deleted    
                  </p>
                  <form  method ="post" action ="del.php"class="forms-sample">
                    <div class="form-group">
                      <label for="exampleInputName1">ticket_number</label>
                      <input type="text" class="form-control" id="exampleInputName1" name="ticket_number" placeholder="Enter ticket number to be deleted    ">
                    </div>
                           <button type="delete" class="btn btn-primary mr-2">Delete</button>
                   
                  </form>
                </div>
              </div>
            </div>
                   <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="vendors/typeahead.js/typeahead.bundle.min.js"></script>
  <script src="vendors/select2/select2.min.js"></script>
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/file-upload.js"></script>
  <script src="js/typeahead.js"></script>
  <script src="js/select2.js"></script>
  <!-- End custom js for this page-->
</body>

</html>
