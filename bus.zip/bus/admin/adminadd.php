<?php
 
	// Check If form submitted, insert form data into trip table.
	if(isset($_POST['Submit'])) {
        $field3 = $_POST['origin'];
        $field4 = $_POST['destination'];
        if( $field3 != $field4){ 
		
            
        $field1 = $_POST['username'];
        $field2 = $_POST['phone'];
        $field3 = $_POST['origin'];
        $field4 = $_POST['destination'];
        $field5 = $_POST['PickupDate'];
        $field6 = $_POST['PickupTime'];
        $field7 = $_POST['ReturnDate'];
        $field8 = $_POST['ReturnTime'];
        $field9 = $_POST['adults'];
        $field10 = $_POST['children'];
        $field11 = $field3.rand (10,100);
        $field12=$field3.rand(1,60);
        $field13 = $field9 + $field10;
        

	
       
        

       
		// include database connection file
		include_once("../config.php");
				
		// Insert user data into table
		$result1 = mysqli_query($mysqli, "INSERT INTO `trip`(`name`, `phone`, `origin`, `destination`, `pickupdate`, `pickuptime`, `returndate`, `returntime`, `adults`, `children`)VALUES('$field1','$field2','$field3','$field4','$field5','$field6','$field7','$field8','$field9','$field10')");
	

      if($field3 == 'kampala' and $field4  == 'jinja' )
      {

                $cost = 30000;
      }else if ($field4 == 'kampala' and $field3  == 'jinja'){
        $cost = 30000;
      
      
      
      
    }else if($field3 == 'wakiso' and $field4  == 'jinja'   )
      {

                    $cost = 40000;
        }else if ( $field4 == 'wakiso' and $field3  == 'jinja'){


            $cost = 40000;


        } 
        
        
        
        
        
        
        else {

                 $cost = 50000;
        }
        $totalcost = $cost* $field13;
                


                $result4 = mysqli_query($mysqli, "INSERT INTO `trip_ticket`(`username`,`phone`,`ticket_number`, `sit_number`, `pickupdate`, `pickuptime`,`returndate`,`returntime`, `origin`, `destination`, `numberofsits`, `costs`) VALUES('$field1','$field2','$field11','$field12','$field5', '$field6','$field7','$field8','$field3','$field4','$field13','$totalcost')");
              
                echo "<script>
                window.location.href = 'crud.php';
              </script>;";                                                                                                                                                         

    

     	
	
	/*	echo "<script>
        window.location.href = 'cost.php';
      </script>;";
      */
      









        }else{
        
        echo"<script>alert('Pickup and Destination cant be the same');</script>";
        echo "<script>
        window.location.href = 'crud.php';
      </script>;";
        }
    }
    





    ///single trip

    // Check If form submitted, insert form data into trip table.
	if(isset($_POST['Submit1'])) {
    $field3 = $_POST['origin'];
    $field4 = $_POST['destination'];
    if( $field3 != $field4){ 

        
    $field1 = $_POST['username'];
    $field2 = $_POST['phone'];
    $field3 = $_POST['origin'];
    $field4 = $_POST['destination'];
    $field5 = $_POST['PickupDate'];
    $field6 = $_POST['PickupTime'];
    $field7 = "N/A";
    $field8 = "N/A";
    $field9 = $_POST['adults'];
    $field10 = $_POST['children'];
    $field11 = $field3.rand (10,100);
    $field12=$field3.rand(1,60);
    $field13 = $field9 + $field10;
    
    


   
    

   
// include database connection file
include_once("../config.php");
    
// Insert user data into table
$result2 = mysqli_query($mysqli, "INSERT INTO `trip`(`name`, `phone`, `origin`, `destination`, `pickupdate`, `pickuptime`, `returndate`, `returntime`, `adults`, `children`)VALUES('$field1','$field2','$field3','$field4','$field5','$field6','$field7','$field8','$field9','$field10')");


  if($field3 == 'kampala' and $field4  == 'jinja' )
  {

            $cost = 30000;
  }else if ($field4 == 'kampala' and $field3  == 'jinja'){
    $cost = 30000;
  
  
  
  
}else if($field3 == 'wakiso' and $field4  == 'jinja'   )
  {

                $cost = 40000;
    }else if ( $field4 == 'wakiso' and $field3  == 'jinja'){


        $cost = 40000;


    } 
    
    
    
    
    
    
    else {

             $cost = 50000;
    }
    $totalcost = $cost* $field13;
           
    

            $result2 = mysqli_query($mysqli, "INSERT INTO `trip_ticket`(`username`,`phone`,`ticket_number`, `sit_number`, `pickupdate`, `pickuptime`,`returndate`,`returntime`, `origin`, `destination`, `numberofsits`, `costs`) VALUES('$field1','$field2','$field11','$field12','$field5', '$field6','$field7','$field8','$field3','$field4','$field13','$totalcost')");
           if(mysqli_query($mysqli, $result)){
              echo "Records inserted successfully.";
              echo "<script>
              window.location.href = 'crud.php';
            </script>;";
          } else{
              echo "ERROR: Could not able to execute2 $result2. " . mysqli_error($mysqli);
          }
                                                                                                                                                                      



   

/*	echo "<script>
    window.location.href = 'cost.php';
  </script>;";
  */
  









    }else{
    
    echo"<script>alert('Pickup and Destination cant be the same');</script>";
    
  echo "<script>
        window.location.href = 'crud.php';
      </script>;";
    }
}



	?>